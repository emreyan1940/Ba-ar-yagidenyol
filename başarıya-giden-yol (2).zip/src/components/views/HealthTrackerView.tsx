import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Award, Moon, Droplets, Plus, Trash2 } from 'lucide-react';

export const HealthTrackerView: React.FC = () => {
  const { state, setState, showToast } = useApp();

  const [sleepStart, setSleepStart] = useState('23:30');
  const [sleepEnd, setSleepEnd] = useState('07:30');
  const [sleepQuality, setSleepQuality] = useState<'İzi' | 'Orta' | 'Kötü'>('İyi' as any);

  const [waterAddMl, setWaterAddMl] = useState(500);

  // Sleep time min calc
  const calcSleepMin = (s: string, e: string) => {
    const [sh, sm] = s.split(':').map(Number);
    const [eh, em] = e.split(':').map(Number);
    let startMin = sh * 60 + sm;
    let endMin = eh * 60 + em;
    if (endMin <= startMin) endMin += 1440;
    return endMin - startMin;
  };

  const handleAddSleep = () => {
    const min = calcSleepMin(sleepStart, sleepEnd);
    const todayStr = new Date().toISOString().slice(0, 10);

    const newRecord = {
      id: `sl_${Date.now()}`,
      date: todayStr,
      start: sleepStart,
      end: sleepEnd,
      min,
      quality: sleepQuality as any
    };

    setState((prev) => ({
      ...prev,
      sleep: [newRecord, ...prev.sleep]
    }));
    showToast(`Uyku süresi eklendi: ${Math.floor(min / 60)} sa ${min % 60} dk`);
  };

  const handleAddWater = (ml: number) => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const currentMl = state.water[todayStr] || 0;

    setState((prev) => ({
      ...prev,
      water: {
        ...prev.water,
        [todayStr]: currentMl + ml
      }
    }));
    showToast(`${ml} ml su eklendi 💧`);
  };

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayWaterMl = state.water[todayStr] || 0;
  const goalWaterMl = (state.waterGoal || 3.5) * 1000;
  const waterPct = Math.min(100, Math.round((todayWaterMl / goalWaterMl) * 100));

  return (
    <div className="space-y-6">
      {/* Streak Badge Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-rose-500/20 border border-amber-500/30 shadow-md space-y-3">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 font-extrabold text-xl">
            🔥
          </div>
          <div>
            <h3 className="font-extrabold text-slate-100 text-lg">Çalışma Serin & Günlük Aktiflik</h3>
            <p className="text-xs text-slate-300">
              Her gün en az 1 görev veya pomodoro tamamlayarak serini koru!
            </p>
          </div>
        </div>
      </div>

      {/* Sleep Tracker */}
      <div className="p-6 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-4">
        <div className="flex items-center gap-2 font-bold text-lg text-slate-100">
          <Moon className="w-5 h-5 text-indigo-400" />
          <h3>Uyku Takibi ve Dinlenme Metriği</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Yatış Saati</label>
            <input
              type="time"
              value={sleepStart}
              onChange={(e) => setSleepStart(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Kalkış Saati</label>
            <input
              type="time"
              value={sleepEnd}
              onChange={(e) => setSleepEnd(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Uyku Kalitesi</label>
            <select
              value={sleepQuality}
              onChange={(e) => setSleepQuality(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            >
              <option value="İyi">İyi</option>
              <option value="Orta">Orta</option>
              <option value="Kötü">Kötü</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleAddSleep}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-indigo-600/30"
        >
          <Plus className="w-4 h-4" />
          <span>Uyku Kaydı Ekle</span>
        </button>

        {/* Sleep History */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          {state.sleep.slice(0, 3).map((s) => (
            <div
              key={s.id}
              className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs flex justify-between items-center"
            >
              <span>{s.date} • {s.start} - {s.end}</span>
              <span className="font-bold text-indigo-400">{Math.floor(s.min / 60)} sa {s.min % 60} dk ({s.quality})</span>
            </div>
          ))}
        </div>
      </div>

      {/* Water Intake Tracker */}
      <div className="p-6 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-4">
        <div className="flex items-center gap-2 font-bold text-lg text-slate-100">
          <Droplets className="w-5 h-5 text-cyan-400" />
          <h3>Günlük Su Tüketimi Takibi</h3>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold text-slate-300">
            <span>Bugünkü Su Miktarı</span>
            <span className="text-cyan-400">{(todayWaterMl / 1000).toFixed(2)} L / {state.waterGoal} L (%{waterPct})</span>
          </div>

          <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden p-0.5 border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-500"
              style={{ width: `${waterPct}%` }}
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-2">
          {[250, 500, 750, 1000].map((ml) => (
            <button
              key={ml}
              onClick={() => handleAddWater(ml)}
              className="px-4 py-2 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 font-bold text-xs flex items-center gap-1 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{ml} ml</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
