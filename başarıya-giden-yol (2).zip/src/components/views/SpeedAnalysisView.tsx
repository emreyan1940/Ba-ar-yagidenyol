import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { COURSES } from '../../data/initialData';
import { Activity, Plus, Trash2 } from 'lucide-react';

export const SpeedAnalysisView: React.FC = () => {
  const { state, setState, showToast } = useApp();

  const [name, setName] = useState('TYT Türkçe Deneme 1');
  const [course, setCourse] = useState(COURSES[0]);
  const [questions, setQuestions] = useState(40);
  const [minutes, setMinutes] = useState(40);
  const [correct, setCorrect] = useState(32);
  const [wrong, setWrong] = useState(5);

  const handleAddSpeedRecord = () => {
    const q = Number(questions) || 1;
    const m = Number(minutes) || 1;
    const d = Number(correct) || 0;

    const perQuestion = Number((m / q).toFixed(2));
    const accuracy = Math.round((d / q) * 100);

    const newRecord = {
      id: `sp_${Date.now()}`,
      date: new Date().toLocaleDateString('tr-TR'),
      name: name.trim() || 'Hız Analizi',
      course,
      questions: q,
      minutes: m,
      correct: d,
      wrong: Number(wrong) || 0,
      perQuestion,
      accuracy
    };

    setState((prev) => ({
      ...prev,
      speedRecords: [newRecord, ...prev.speedRecords]
    }));

    showToast('Hız analizi kaydedildi');
  };

  const handleDelete = (id: string) => {
    setState((prev) => ({
      ...prev,
      speedRecords: prev.speedRecords.filter((s) => s.id !== id)
    }));
  };

  return (
    <div className="space-y-6">
      <div className="p-6 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-4">
        <div className="flex items-center gap-2 font-bold text-lg text-slate-100">
          <Activity className="w-5 h-5 text-cyan-400" />
          <h3>Soru Çözüm Hızı ve Doğruluk Analizi</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Çalışma / Deneme Adı</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Ders</label>
            <select
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            >
              {COURSES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Soru Sayısı</label>
            <input
              type="number"
              value={questions}
              onChange={(e) => setQuestions(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Geçen Süre (Dakika)</label>
            <input
              type="number"
              value={minutes}
              onChange={(e) => setMinutes(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Doğru Sayısı</label>
            <input
              type="number"
              value={correct}
              onChange={(e) => setCorrect(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Yanlış Sayısı</label>
            <input
              type="number"
              value={wrong}
              onChange={(e) => setWrong(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>
        </div>

        <button
          onClick={handleAddSpeedRecord}
          className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-cyan-600/30"
        >
          <Plus className="w-4 h-4" />
          <span>Hız Analizini Kaydet</span>
        </button>
      </div>

      {/* Record Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {state.speedRecords.map((r) => (
          <div
            key={r.id}
            className="p-5 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-3 relative group"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="font-bold text-slate-100 text-base">{r.name}</div>
                <div className="text-xs text-slate-400">{r.course} • {r.date}</div>
              </div>
              <button
                onClick={() => handleDelete(r.id)}
                className="text-slate-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center">
              <div className="p-2 rounded-xl bg-slate-950/60">
                <span className="text-[10px] text-slate-400 block font-semibold">Hız</span>
                <span className="text-sm font-extrabold text-cyan-400">{r.perQuestion} dk/soru</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-950/60">
                <span className="text-[10px] text-slate-400 block font-semibold">Doğruluk</span>
                <span className="text-sm font-extrabold text-emerald-400">%{r.accuracy}</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-950/60">
                <span className="text-[10px] text-slate-400 block font-semibold">Soru / Süre</span>
                <span className="text-sm font-extrabold text-slate-200">{r.questions} S / {r.minutes} dk</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
