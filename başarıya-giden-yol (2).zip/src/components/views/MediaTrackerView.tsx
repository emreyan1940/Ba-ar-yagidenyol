import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Film, Plus, Trash2, Star } from 'lucide-react';

export const MediaTrackerView: React.FC = () => {
  const { state, setState, showToast } = useApp();

  const [title, setTitle] = useState('Prison Break');
  const [kind, setKind] = useState<'Film' | 'Dizi' | 'Anime' | 'Belgesel'>('Dizi');
  const [status, setStatus] = useState<'İzlenecek' | 'İzleniyor' | 'Bitti' | 'Bırakıldı'>('İzleniyor');
  const [season, setSeason] = useState(1);
  const [episode, setEpisode] = useState(5);
  const [score, setScore] = useState(9.0);
  const [note, setNote] = useState('');

  const handleAddMedia = () => {
    if (!title.trim()) {
      showToast('Film / Dizi adı giriniz.', 'warning');
      return;
    }

    const newItem = {
      id: `media_${Date.now()}`,
      title: title.trim(),
      kind,
      status,
      season: Number(season) || 1,
      episode: Number(episode) || 1,
      score: Number(score) || 0,
      note,
      date: new Date().toLocaleDateString('tr-TR')
    };

    setState((prev) => ({
      ...prev,
      media: [newItem, ...prev.media]
    }));

    setTitle('');
    setNote('');
    showToast('Film / Dizi takip listesine eklendi');
  };

  const handleDelete = (id: string) => {
    setState((prev) => ({
      ...prev,
      media: prev.media.filter((m) => m.id !== id)
    }));
  };

  const handleUpdateStatus = (id: string, newStatus: any) => {
    setState((prev) => ({
      ...prev,
      media: prev.media.map((m) => (m.id === id ? { ...m, status: newStatus } : m))
    }));
  };

  return (
    <div className="space-y-6">
      <div className="p-6 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-4">
        <div className="flex items-center gap-2 font-bold text-lg text-slate-100">
          <Film className="w-5 h-5 text-indigo-400" />
          <h3>Film, Dizi & Mola Takip Defteri</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Eser Adı</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Örn: Dexter, Interstellar..."
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Tür</label>
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            >
              <option value="Dizi">Dizi</option>
              <option value="Film">Film</option>
              <option value="Anime">Anime</option>
              <option value="Belgesel">Belgesel</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Durum</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            >
              <option value="İzleniyor">İzleniyor</option>
              <option value="İzlenecek">İzlenecek</option>
              <option value="Bitti">Bitti</option>
              <option value="Bırakıldı">Bırakıldı</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Sezon / Bölüm / Puan</label>
            <div className="grid grid-cols-3 gap-1">
              <input
                type="number"
                value={season}
                onChange={(e) => setSeason(Number(e.target.value))}
                placeholder="Sezon"
                className="px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs text-center"
              />
              <input
                type="number"
                value={episode}
                onChange={(e) => setEpisode(Number(e.target.value))}
                placeholder="Bölüm"
                className="px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs text-center"
              />
              <input
                type="number"
                step="0.1"
                value={score}
                onChange={(e) => setScore(Number(e.target.value))}
                placeholder="Puan"
                className="px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs text-center font-bold text-amber-400"
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1">Not / Yorum</label>
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Kaldığım yer veya kişisel yorumum..."
            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
          />
        </div>

        <button
          onClick={handleAddMedia}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-indigo-600/30"
        >
          <Plus className="w-4 h-4" />
          <span>Listeye Ekle</span>
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {state.media.map((m) => (
          <div
            key={m.id}
            className="p-5 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-3 relative group"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="font-extrabold text-slate-100 text-base">{m.title}</div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                  <span>{m.kind}</span>
                  <span>•</span>
                  <span>S{m.season} B{m.episode}</span>
                  <span>•</span>
                  <span className="flex items-center text-amber-400 font-bold gap-0.5">
                    <Star className="w-3 h-3 fill-amber-400" /> {m.score}
                  </span>
                </div>
              </div>

              <button
                onClick={() => handleDelete(m.id)}
                className="text-slate-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <select
                value={m.status}
                onChange={(e) => handleUpdateStatus(m.id, e.target.value)}
                className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 text-xs font-bold text-slate-200"
              >
                <option value="İzleniyor">İzleniyor</option>
                <option value="İzlenecek">İzlenecek</option>
                <option value="Bitti">Bitti</option>
                <option value="Bırakıldı">Bırakıldı</option>
              </select>

              <span className="text-[11px] text-slate-500">{m.date}</span>
            </div>

            {m.note && <p className="text-xs text-slate-300 italic pt-1">{m.note}</p>}
          </div>
        ))}
      </div>
    </div>
  );
};
