import React from 'react';
import { useApp } from '../../context/AppContext';
import { BarChart3, Flame, CheckCircle, Video, BookOpen, Layers } from 'lucide-react';

export const CampProgressCenterView: React.FC = () => {
  const { state, setActiveTab } = useApp();

  return (
    <div className="space-y-6">
      <div className="p-6 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-2">
        <div className="flex items-center gap-2 font-bold text-lg text-slate-100">
          <BarChart3 className="w-5 h-5 text-amber-400" />
          <h3>Kamp İlerleme ve Genel Genel Bakış Merkezi</h3>
        </div>
        <p className="text-xs text-slate-400">
          Takip ettiğin tüm YKS kamplarının tam ilerleme durumunu ve istatistiklerini tek bir ekranda incele.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {state.camps.map((camp) => {
          const completedDays = camp.items.filter((i) => i.done).length;
          const totalDays = camp.items.length;
          const pct = totalDays ? Math.round((completedDays / totalDays) * 100) : 0;

          const totalVideos = camp.items.reduce((acc, curr) => acc + (Number(curr.videoCount) || 0), 0);
          const totalTests = camp.items.reduce((acc, curr) => acc + (Number(curr.testCount) || 0), 0);
          const totalQuestions = camp.items.reduce((acc, curr) => acc + (Number(curr.questionCount) || 0), 0);

          return (
            <div
              key={camp.id}
              className="p-5 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-4 hover:border-amber-500/50 transition-all"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-extrabold text-slate-100 text-base flex items-center gap-2">
                    <Flame className="w-4 h-4 text-rose-500" />
                    <span>{camp.name}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">{camp.course} • {totalDays} Günlük Müfredat</div>
                </div>

                <button
                  onClick={() => setActiveTab('camps')}
                  className="px-3 py-1 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 font-bold text-xs"
                >
                  Detay
                </button>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold text-slate-300">
                  <span>Tamamlanma Oranı</span>
                  <span className="text-emerald-400">%{pct} ({completedDays}/{totalDays} Gün)</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden p-0.5 border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              {/* Sub Stats */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center text-xs font-semibold">
                <div className="p-2 rounded-xl bg-slate-950/60 text-slate-300">
                  <Video className="w-3.5 h-3.5 mx-auto text-blue-400 mb-1" />
                  <span>{totalVideos} Video</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/60 text-slate-300">
                  <Layers className="w-3.5 h-3.5 mx-auto text-purple-400 mb-1" />
                  <span>{totalTests} Test</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/60 text-slate-300">
                  <BookOpen className="w-3.5 h-3.5 mx-auto text-amber-400 mb-1" />
                  <span>{totalQuestions} Soru</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
