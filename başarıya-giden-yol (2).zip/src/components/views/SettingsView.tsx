import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Settings, Download, Upload, RefreshCw, Key, Calendar } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { state, setState, saveState, resetData, toggleTheme, showToast } = useApp();

  const [apiKeyInput, setApiKeyInput] = useState(state.apiKey || '');
  const [yksDateInput, setYksDateInput] = useState(state.yksDate || '2027-06-19');

  const handleSaveApiKey = () => {
    setState((prev) => ({
      ...prev,
      apiKey: apiKeyInput.trim(),
      yksDate: yksDateInput
    }));
    saveState();
    showToast('Ayarlar başarıyla kaydedildi!');
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `basariya_giden_yol_yedek_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Tüm verileriniz JSON yedeği olarak indirildi!');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && typeof parsed === 'object') {
          saveState(parsed);
          showToast('Yedek veriler başarıyla yüklendi!');
        }
      } catch (err) {
        showToast('Yedek dosyası okunamadı. Geçerli bir JSON yükleyin.', 'warning');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      {/* Settings Card */}
      <div className="p-6 rounded-2xl bg-slate-800/80 dark:bg-slate-900/80 border border-slate-700/80 shadow-md space-y-6">
        <div className="flex items-center gap-2 font-bold text-lg text-slate-100 border-b border-slate-700 pb-3">
          <Settings className="w-5 h-5 text-blue-400" />
          <h3>Sistem ve Uygulama Ayarları</h3>
        </div>

        {/* YKS Date & Key */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <span>YKS Sınav Tarihi</span>
            </label>
            <input
              type="date"
              value={yksDateInput}
              onChange={(e) => setYksDateInput(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
              <Key className="w-4 h-4 text-amber-400" />
              <span>AI Koç API Key (Opsiyonel)</span>
            </label>
            <input
              type="password"
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="sk-..."
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-sm focus:outline-none"
            />
          </div>

          <button
            onClick={handleSaveApiKey}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all shadow-md shadow-blue-600/30"
          >
            Ayaıları Kaydet
          </button>
        </div>

        {/* Backup & Theme Controls */}
        <div className="pt-4 border-t border-slate-700/80 space-y-3">
          <h4 className="font-bold text-sm text-slate-200">Veri Yedekleme ve Kurtarma</h4>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={handleExportJSON}
              className="px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-100 font-bold text-xs flex items-center gap-2 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Verileri Dışa Aktar (JSON)</span>
            </button>

            <label className="px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-100 font-bold text-xs flex items-center gap-2 cursor-pointer transition-all">
              <Upload className="w-4 h-4" />
              <span>Yedek Yükle (JSON)</span>
              <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
            </label>

            <button
              onClick={toggleTheme}
              className="px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-100 font-bold text-xs flex items-center gap-2 transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Aydınlık/Karanlık Mod</span>
            </button>
          </div>
        </div>

        {/* Reset */}
        <div className="pt-4 border-t border-slate-700/80 space-y-2">
          <h4 className="font-bold text-sm text-rose-400">Tehlikeli Bölge</h4>
          <p className="text-xs text-slate-400">Tüm verilerinizi tamamen temizleyip fabrika ayarlarına dönün.</p>

          <button
            onClick={resetData}
            className="px-4 py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 font-bold text-xs transition-all"
          >
            Tüm Verileri Sıfırla
          </button>
        </div>
      </div>
    </div>
  );
};
